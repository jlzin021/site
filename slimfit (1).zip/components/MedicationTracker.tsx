import React, { useState } from 'react';
import { Medication } from '../types';
import { IconCheck, IconPill } from './Icons';

interface MedicationTrackerProps {
  medications: Medication[];
  onToggle: (id: string) => void;
  onAdd: (med: Medication) => void;
  onDelete: (id: string) => void;
}

const MedicationTracker: React.FC<MedicationTrackerProps> = ({ medications, onToggle, onAdd, onDelete }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newMed, setNewMed] = useState({
    name: '',
    dosage: '',
    time: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMed.name || !newMed.time) return;

    onAdd({
      id: Date.now().toString(),
      name: newMed.name,
      dosage: newMed.dosage,
      time: newMed.time,
      taken: false
    });

    setNewMed({ name: '', dosage: '', time: '' });
    setIsModalOpen(false);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
           <h2 className="text-2xl font-bold text-slate-800">Seus Medicamentos</h2>
           <p className="text-slate-500">Gerencie sua rotina diária de medicação.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm"
        >
            Adicionar Novo
        </button>
      </div>

      <div className="space-y-4">
        {medications.sort((a,b) => a.time.localeCompare(b.time)).map((med) => (
          <div 
            key={med.id} 
            className={`flex items-center justify-between p-5 rounded-xl border transition-all duration-300 group ${
              med.taken 
                ? 'bg-emerald-50 border-emerald-200 opacity-75' 
                : 'bg-white border-slate-200 hover:border-blue-300 hover:shadow-md'
            }`}
          >
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-full ${med.taken ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-blue-600'}`}>
                <IconPill className="w-6 h-6" />
              </div>
              <div>
                <h3 className={`font-semibold text-lg ${med.taken ? 'text-emerald-900 line-through' : 'text-slate-800'}`}>
                    {med.name}
                </h3>
                <p className="text-sm text-slate-500">
                    {med.dosage} • <span className="font-medium text-slate-700">{med.time}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {!med.taken && (
                 <button
                 onClick={() => onDelete(med.id)}
                 className="text-slate-300 hover:text-red-500 text-sm font-medium px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity"
               >
                 Excluir
               </button>
              )}
             
              <button
                onClick={() => onToggle(med.id)}
                className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                  med.taken
                    ? 'bg-emerald-500 border-emerald-500 text-white'
                    : 'bg-transparent border-slate-300 text-transparent hover:border-emerald-400'
                }`}
              >
                <IconCheck className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}

        {medications.length === 0 && (
             <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300">
                <IconPill className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500 font-medium">Nenhum medicamento cadastrado.</p>
                <p className="text-slate-400 text-sm">Adicione um lembrete para começar.</p>
             </div>
        )}
      </div>

      {/* Modal Overlay */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl animate-fade-in-up">
            <h3 className="text-xl font-bold text-slate-800 mb-4">Adicionar Medicamento</h3>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Nome do Medicamento</label>
                <input 
                  type="text" 
                  required
                  className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Ex: Vitamina C"
                  value={newMed.name}
                  onChange={e => setNewMed({...newMed, name: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Dosagem (Opcional)</label>
                  <input 
                    type="text" 
                    className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Ex: 500mg"
                    value={newMed.dosage}
                    onChange={e => setNewMed({...newMed, dosage: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Horário</label>
                  <input 
                    type="time" 
                    required
                    className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    value={newMed.time}
                    onChange={e => setNewMed({...newMed, time: e.target.value})}
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6 pt-4 border-t border-slate-100">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 text-slate-600 font-medium hover:bg-slate-50 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
                >
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MedicationTracker;