
import React, { useState, useEffect } from 'react';
import { supabase } from '../services/supabaseClient';
import { createProfile } from '../services/dataService';
import { IconSparkles, IconUser, IconLock, IconCheck } from './Icons';

interface AuthScreenProps {
  onLoginSuccess: () => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onLoginSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [cachedName, setCachedName] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    username: '', // Used for profile display
    password: ''
  });

  useEffect(() => {
    const savedName = localStorage.getItem('slimfit_user_name');
    if (savedName) {
        setCachedName(savedName.split(' ')[0]);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError('');
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (isLogin) {
        // LOGIN
        const { error } = await supabase.auth.signInWithPassword({
          email: formData.email,
          password: formData.password
        });
        if (error) throw error;
        // Success handled by onAuthStateChange in App.tsx
      } else {
        // REGISTER
        if (!formData.name || !formData.username) {
            throw new Error("Nome e Usuário são obrigatórios.");
        }

        const { data, error: signUpError } = await supabase.auth.signUp({
          email: formData.email,
          password: formData.password,
        });

        if (signUpError) throw signUpError;

        if (data.user) {
          // Create custom profile entry
          await createProfile(data.user.id, formData.name, formData.username);
          localStorage.setItem('slimfit_user_name', formData.name);
        }
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Ocorreu um erro. Verifique seus dados.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      
      <div className="mb-8 text-center animate-fade-in-up">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-200">
            <IconSparkles className="text-white w-8 h-8" />
        </div>
        <h1 className="text-3xl font-bold text-slate-800 tracking-tight">SlimFit</h1>
        <p className="text-slate-500 mt-2">
            {isLogin 
                ? (cachedName ? `Bem-vindo de volta, ${cachedName}!` : 'Bem-vindo de volta') 
                : 'Crie sua conta gratuita'
            }
        </p>
      </div>

      <div className="bg-white rounded-3xl shadow-xl w-full max-w-md p-8 border border-slate-100 animate-fade-in-up">
        
        {/* Toggle */}
        <div className="flex justify-center mb-8 border-b border-slate-100 pb-2">
            <button 
                onClick={() => { setIsLogin(true); setError(''); }}
                className={`pb-2 px-6 font-medium text-sm transition-colors ${isLogin ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
            >
                Entrar
            </button>
            <button 
                onClick={() => { setIsLogin(false); setError(''); }}
                className={`pb-2 px-6 font-medium text-sm transition-colors ${!isLogin ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
            >
                Criar Conta
            </button>
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
            
            {!isLogin && (
                <>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Nome Completo</label>
                        <input 
                            type="text" 
                            name="name"
                            required
                            value={formData.name}
                            onChange={handleChange}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                            placeholder="Seu nome"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Nome de Usuário</label>
                        <div className="relative">
                            <IconUser className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                            <input 
                                type="text" 
                                name="username"
                                required
                                value={formData.username}
                                onChange={handleChange}
                                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                                placeholder="usuario123"
                            />
                        </div>
                    </div>
                </>
            )}

            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">E-mail</label>
                <input 
                    type="email" 
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="exemplo@email.com"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Senha</label>
                <div className="relative">
                    <IconLock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input 
                        type="password" 
                        name="password"
                        required
                        minLength={6}
                        value={formData.password}
                        onChange={handleChange}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="••••••••"
                    />
                </div>
            </div>

            {error && (
                <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg text-center font-medium border border-red-100">
                    {error}
                </div>
            )}

            <button 
                type="submit"
                disabled={loading}
                className={`w-full py-3 text-white font-bold rounded-xl transition-all shadow-lg mt-2 flex items-center justify-center gap-2 ${
                    loading ? 'bg-slate-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-200 transform active:scale-95'
                }`}
            >
                {loading && <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                {!loading && (isLogin ? 'Entrar' : 'Criar Conta')}
            </button>
        </form>
      </div>

      <p className="mt-8 text-slate-400 text-sm">
        © 2025 SlimFit. Dados seguros com Supabase.
      </p>
    </div>
  );
};

export default AuthScreen;
