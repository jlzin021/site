
import React from 'react';
import { DailyStats } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

interface DashboardProps {
  stats: DailyStats;
  userName?: string;
}

const Dashboard: React.FC<DashboardProps> = ({ stats, userName }) => {
  const waterData = [
    { name: 'Consumido', value: stats.waterCurrent, color: '#3b82f6' },
    { name: 'Restante', value: Math.max(0, stats.waterGoal - stats.waterCurrent), color: '#e2e8f0' },
  ];

  const weeklyData = [
    { name: 'Seg', agua: 2000, remedios: 100 },
    { name: 'Ter', agua: 2500, remedios: 80 },
    { name: 'Qua', agua: 1800, remedios: 100 },
    { name: 'Qui', agua: 2200, remedios: 100 },
    { name: 'Sex', agua: stats.waterCurrent, remedios: 100 }, // Current day simulation
    { name: 'Sab', agua: 0, remedios: 0 },
    { name: 'Dom', agua: 0, remedios: 0 },
  ];

  const firstName = userName ? userName.split(' ')[0] : 'Usuário';

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between">
          <h3 className="text-slate-500 text-sm font-medium">Hidratação Hoje</h3>
          <div className="flex items-end gap-2 mt-2">
            <span className="text-3xl font-bold text-blue-600">{stats.waterCurrent}</span>
            <span className="text-slate-400 mb-1">/ {stats.waterGoal} ml</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full mt-4 overflow-hidden">
            <div 
              className="bg-blue-500 h-full rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(100, (stats.waterCurrent / stats.waterGoal) * 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between">
          <h3 className="text-slate-500 text-sm font-medium">Remédios</h3>
          <div className="flex items-end gap-2 mt-2">
            <span className="text-3xl font-bold text-emerald-500">{stats.medicationTaken}</span>
            <span className="text-slate-400 mb-1">/ {stats.medicationTotal} tomados</span>
          </div>
          <div className="mt-4 text-xs text-slate-500">
            {stats.medicationTaken === stats.medicationTotal ? "Tudo certo por hoje!" : "Pendente"}
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between">
            <h3 className="text-slate-500 text-sm font-medium">Bem-estar de {firstName}</h3>
             <div className="flex items-end gap-2 mt-2">
                <span className="text-3xl font-bold text-purple-500">Ótimo</span>
            </div>
             <p className="mt-4 text-xs text-slate-500">Baseado no seu histórico</p>
        </div>

         <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-6 rounded-2xl shadow-lg text-white flex flex-col justify-between">
            <h3 className="text-blue-100 text-sm font-medium">Dica do Dia</h3>
            <p className="mt-2 text-sm leading-relaxed">
               "Lembre-se de alongar a cada 2 horas se estiver trabalhando sentado."
            </p>
            <div className="mt-4 text-xs text-blue-200 font-semibold">SlimFit AI</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Progresso da Água</h3>
            <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={waterData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                        >
                            {waterData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                        </Pie>
                         <Tooltip />
                    </PieChart>
                </ResponsiveContainer>
            </div>
             <div className="text-center text-sm text-slate-500 -mt-4">Hoje</div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
             <h3 className="text-lg font-semibold text-slate-800 mb-4">Histórico Semanal</h3>
             <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={weeklyData}>
                        <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis hide />
                        <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                        <Bar dataKey="agua" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
             </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
