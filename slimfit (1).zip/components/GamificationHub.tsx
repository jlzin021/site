

import React from 'react';
import { GamificationProfile, Achievement } from '../types';
import { IconTrophy, IconMedal, IconFlag, IconStar, IconCrown, IconLock } from './Icons';

interface GamificationHubProps {
  profile: GamificationProfile;
}

// Configuração dos Níveis
const LEVEL_THRESHOLDS = [0, 100, 300, 600, 1000, 1500, 2500, 5000];

// Lista completa de conquistas possíveis (para exibir as bloqueadas)
const ALL_ACHIEVEMENTS: Omit<Achievement, 'unlockedAt'>[] = [
  { id: 'first_login', title: 'Primeiro Passo', description: 'Criou sua conta no SlimFit.', iconType: 'flag' },
  { id: 'water_master', title: 'Mestre da Hidratação', description: 'Atingiu a meta de água do dia.', iconType: 'medal' },
  { id: 'med_perfect', title: 'Farmácia em Dia', description: 'Tomou todos os medicamentos do dia.', iconType: 'star' },
  { id: 'nutrition_start', title: 'Nutrição Consciente', description: 'Registrou sua primeira refeição.', iconType: 'medal' },
  { id: 'streak_3', title: 'Consistência', description: '3 dias seguidos de metas cumpridas.', iconType: 'trophy' },
  { id: 'level_5', title: 'Veterano da Saúde', description: 'Alcançou o Nível 5.', iconType: 'crown' },
];

const GamificationHub: React.FC<GamificationHubProps> = ({ profile }) => {
  const currentLevel = profile.level;
  const nextLevelXp = LEVEL_THRESHOLDS[currentLevel] || LEVEL_THRESHOLDS[LEVEL_THRESHOLDS.length - 1];
  const prevLevelXp = LEVEL_THRESHOLDS[currentLevel - 1] || 0;
  
  // Calcular progresso da barra
  const levelProgress = Math.min(100, Math.max(0, ((profile.xp - prevLevelXp) / (nextLevelXp - prevLevelXp)) * 100));

  const getIcon = (type: string, className: string) => {
    switch(type) {
      case 'medal': return <IconMedal className={className} />;
      case 'trophy': return <IconTrophy className={className} />;
      case 'flag': return <IconFlag className={className} />;
      case 'star': return <IconStar className={className} />;
      case 'crown': return <IconCrown className={className} />;
      default: return <IconMedal className={className} />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      
      {/* Banner Principal - Nível e XP */}
      <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-10 transform translate-x-1/4 -translate-y-1/4">
           <IconTrophy className="w-64 h-64" />
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="relative">
            <div className="w-32 h-32 rounded-full bg-white/20 flex items-center justify-center border-4 border-yellow-400 shadow-[0_0_20px_rgba(250,204,21,0.5)]">
               <span className="text-5xl font-black text-white">{currentLevel}</span>
            </div>
            <div className="absolute -bottom-2 w-full text-center">
               <span className="bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">Nível</span>
            </div>
          </div>
          
          <div className="flex-1 w-full">
             <div className="flex justify-between items-end mb-2">
               <h2 className="text-2xl font-bold">Sua Jornada</h2>
               <span className="font-mono text-indigo-100">{profile.xp} / {nextLevelXp} XP</span>
             </div>
             
             <div className="h-6 bg-black/20 rounded-full overflow-hidden backdrop-blur-sm border border-white/10 relative">
               <div 
                  className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full transition-all duration-1000 ease-out relative"
                  style={{ width: `${levelProgress}%` }}
               >
                  <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
               </div>
             </div>
             <p className="mt-2 text-sm text-indigo-200">
               Faltam {nextLevelXp - profile.xp} XP para o próximo nível. Continue assim!
             </p>
          </div>
        </div>
      </div>

      {/* Seção de Conquistas (Medalhas/Badges) */}
      <div>
         <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
            <IconMedal className="w-6 h-6 text-yellow-500" />
            Galeria de Conquistas
         </h3>
         
         <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {ALL_ACHIEVEMENTS.map(achiev => {
               const isUnlocked = profile.unlockedAchievements.some(u => u.id === achiev.id);
               
               return (
                  <div 
                    key={achiev.id} 
                    className={`
                       relative p-4 rounded-xl border flex flex-col items-center text-center transition-all duration-300
                       ${isUnlocked 
                          ? 'bg-white border-yellow-200 shadow-md transform hover:-translate-y-1' 
                          : 'bg-slate-50 border-slate-200 opacity-60 grayscale'
                       }
                    `}
                  >
                     <div className={`
                        w-16 h-16 rounded-full flex items-center justify-center mb-3
                        ${isUnlocked ? 'bg-yellow-100 text-yellow-600' : 'bg-slate-200 text-slate-400'}
                     `}>
                        {isUnlocked ? getIcon(achiev.iconType, "w-8 h-8") : <IconLock className="w-6 h-6" />}
                     </div>
                     
                     <h4 className={`font-bold text-sm mb-1 ${isUnlocked ? 'text-slate-800' : 'text-slate-500'}`}>
                        {achiev.title}
                     </h4>
                     <p className="text-xs text-slate-500 leading-tight">
                        {achiev.description}
                     </p>
                     
                     {isUnlocked && (
                        <span className="absolute top-2 right-2 w-2 h-2 bg-green-500 rounded-full"></span>
                     )}
                  </div>
               );
            })}
         </div>
      </div>

      {/* Seção de Colecionáveis (Bandeiras/Insígnias) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
             <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                <IconFlag className="w-5 h-5 text-indigo-500" />
                Bandeiras de Marcos
             </h3>
             <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
                {/* Exemplo de Bandeiras visuais desbloqueadas por nível */}
                {[1, 5, 10, 20].map(lvl => (
                   <div key={lvl} className={`flex-shrink-0 flex flex-col items-center ${currentLevel >= lvl ? '' : 'opacity-40 grayscale'}`}>
                      <div className={`w-12 h-16 bg-gradient-to-b ${currentLevel >= lvl ? 'from-blue-500 to-indigo-600' : 'from-slate-300 to-slate-400'} rounded-b-lg shadow-sm flex items-center justify-center text-white font-bold`}>
                         {lvl}
                      </div>
                      <span className="text-[10px] mt-1 font-semibold text-slate-500">Nível {lvl}</span>
                   </div>
                ))}
             </div>
         </div>

         <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
             <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                <IconCrown className="w-5 h-5 text-purple-500" />
                Insígnias Especiais
             </h3>
             <div className="space-y-3">
                <div className="flex items-center gap-3 p-2 bg-purple-50 rounded-lg border border-purple-100">
                   <div className="p-2 bg-white rounded-full text-purple-600 shadow-sm"><IconStar className="w-4 h-4"/></div>
                   <div>
                      <p className="text-sm font-bold text-purple-900">Membro Fundador</p>
                      <p className="text-xs text-purple-600">Esteve aqui desde o início.</p>
                   </div>
                </div>
                {/* Placeholder para futuras insígnias */}
                <div className="flex items-center gap-3 p-2 bg-slate-50 rounded-lg border border-dashed border-slate-200">
                   <div className="p-2 bg-slate-200 rounded-full text-slate-400"><IconLock className="w-4 h-4"/></div>
                   <div>
                      <p className="text-sm font-bold text-slate-500">???</p>
                      <p className="text-xs text-slate-400">Desbloqueie em eventos especiais.</p>
                   </div>
                </div>
             </div>
         </div>
      </div>

    </div>
  );
};

export default GamificationHub;