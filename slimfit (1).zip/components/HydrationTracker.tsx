import React, { useState } from 'react';
import { DailyStats } from '../types';
import { IconDroplet } from './Icons';

interface HydrationTrackerProps {
  stats: DailyStats;
  onAddWater: (amount: number) => void;
  onUpdateGoal: (newGoal: number) => void;
}

const HydrationTracker: React.FC<HydrationTrackerProps> = ({ stats, onAddWater, onUpdateGoal }) => {
  const [addingAmount, setAddingAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  
  // Goal Editing State
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [tempGoal, setTempGoal] = useState(stats.waterGoal.toString());

  const percentage = Math.min(100, Math.round((stats.waterCurrent / stats.waterGoal) * 100));

  const handleCustomAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseInt(customAmount);
    if (!isNaN(amount) && amount > 0) {
      onAddWater(amount);
      setCustomAmount('');
    }
  };

  const handleGoalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const goal = parseInt(tempGoal);
    if (!isNaN(goal) && goal > 0) {
      onUpdateGoal(goal);
      setIsEditingGoal(false);
    }
  };

  return (
    <div className="max-w-md mx-auto animate-fade-in">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Controle de Hidratação</h2>
        <p className="text-slate-500">Mantenha-se hidratado para ter mais energia.</p>
      </div>

      {/* Visual Bottle Representation */}
      <div className="relative w-40 h-64 mx-auto bg-blue-50 rounded-[3rem] border-4 border-white shadow-xl overflow-hidden mb-8 ring-1 ring-slate-200 group cursor-pointer" onClick={() => onAddWater(200)}>
        <div 
            className="absolute bottom-0 left-0 w-full bg-blue-500 transition-all duration-1000 ease-in-out flex items-center justify-center"
            style={{ height: `${percentage}%` }}
        >
            <div className="w-full h-full opacity-30 animate-pulse bg-blue-400 absolute top-0 left-0"></div>
        </div>
        <div className="absolute inset-0 flex items-center justify-center z-10 flex-col pointer-events-none">
            <span className={`text-3xl font-bold ${percentage > 50 ? 'text-white' : 'text-blue-600'}`}>
                {percentage}%
            </span>
            <span className={`text-xs ${percentage > 50 ? 'text-blue-100' : 'text-blue-400'}`}>da meta</span>
        </div>
        
        {/* Add hint overlay */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <div className="bg-white/90 p-2 rounded-full shadow-sm text-blue-600">
                <IconDroplet className="w-6 h-6" />
            </div>
        </div>
      </div>

      <div className="text-center mb-8">
        <span className="text-4xl font-bold text-slate-800">{stats.waterCurrent}</span>
        <span className="text-xl text-slate-400 mx-1">/</span>
        
        {isEditingGoal ? (
            <form onSubmit={handleGoalSubmit} className="inline-block">
                <input 
                    type="number" 
                    value={tempGoal}
                    onChange={(e) => setTempGoal(e.target.value)}
                    className="w-24 text-xl border-b-2 border-blue-500 text-center outline-none bg-transparent"
                    autoFocus
                    onBlur={() => {
                         const goal = parseInt(tempGoal);
                         if (!isNaN(goal) && goal > 0) onUpdateGoal(goal);
                         setIsEditingGoal(false);
                    }}
                />
            </form>
        ) : (
            <span 
                className="text-xl text-slate-400 border-b border-dashed border-slate-300 hover:text-blue-500 hover:border-blue-500 cursor-pointer transition-colors"
                onClick={() => {
                    setTempGoal(stats.waterGoal.toString());
                    setIsEditingGoal(true);
                }}
                title="Clique para editar a meta"
            >
                 {stats.waterGoal} ml
            </span>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {[200, 300, 500].map((amount) => (
          <button
            key={amount}
            onClick={() => {
                setAddingAmount(amount);
                onAddWater(amount);
                setTimeout(() => setAddingAmount(null), 500);
            }}
            className={`
                relative overflow-hidden
                flex flex-col items-center justify-center py-4 rounded-xl border transition-all
                ${addingAmount === amount 
                    ? 'bg-blue-600 border-blue-600 text-white transform scale-95' 
                    : 'bg-white border-slate-200 text-slate-600 hover:border-blue-300 hover:shadow-md hover:-translate-y-1'
                }
            `}
          >
            <IconDroplet className={`w-6 h-6 mb-2 ${addingAmount === amount ? 'text-white' : 'text-blue-500'}`} />
            <span className="font-semibold text-sm">+{amount}ml</span>
          </button>
        ))}
      </div>
      
      {/* Custom Amount Input */}
      <form onSubmit={handleCustomAdd} className="flex gap-2 mb-8">
        <input 
            type="number" 
            placeholder="Outra quantidade (ml)" 
            className="flex-1 px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
            value={customAmount}
            onChange={(e) => setCustomAmount(e.target.value)}
        />
        <button 
            type="submit" 
            disabled={!customAmount}
            className="px-4 py-2 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
            Adicionar
        </button>
      </form>
      
      <div className="flex justify-center">
         <button 
            onClick={() => onAddWater(-stats.waterCurrent)}
            className="text-xs text-red-400 hover:text-red-600 hover:underline"
         >
            Resetar contador do dia
         </button>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-xl flex items-start gap-3">
        <div className="p-2 bg-blue-100 rounded-full text-blue-600 mt-1">
            <IconDroplet className="w-4 h-4" />
        </div>
        <div>
            <h4 className="font-semibold text-blue-900 text-sm">Por que beber água?</h4>
            <p className="text-blue-700 text-xs mt-1">A hidratação adequada melhora o foco, a digestão e a saúde da pele.</p>
        </div>
      </div>
    </div>
  );
};

export default HydrationTracker;