import React, { useState } from 'react';
import { DailyStats, FoodItem, MealType, MealReminder } from '../types';
import { IconApple, IconSparkles, IconClock } from './Icons';
import { analyzeNutrition } from '../services/geminiService';

interface NutritionTrackerProps {
  stats: DailyStats;
  foodLog: FoodItem[];
  mealReminders: MealReminder[];
  onAddFood: (item: FoodItem) => void;
  onRemoveFood: (id: string) => void;
  onUpdateGoal: (calories: number) => void;
  onUpdateReminders: (reminders: MealReminder[]) => void;
}

const NutritionTracker: React.FC<NutritionTrackerProps> = ({ 
    stats, 
    foodLog, 
    mealReminders,
    onAddFood, 
    onRemoveFood, 
    onUpdateGoal,
    onUpdateReminders
}) => {
  const [input, setInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedMeal, setSelectedMeal] = useState<MealType>('breakfast');
  
  // Goal Editing State
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [tempGoal, setTempGoal] = useState(stats.caloriesGoal.toString());

  // Reminder Modal State
  const [isReminderModalOpen, setIsReminderModalOpen] = useState(false);
  const [tempReminders, setTempReminders] = useState<MealReminder[]>(mealReminders);

  const mealsList: { key: MealType; label: string }[] = [
    { key: 'breakfast', label: 'Café da Manhã' },
    { key: 'lunch', label: 'Almoço' },
    { key: 'snack', label: 'Lanches' },
    { key: 'dinner', label: 'Jantar' },
  ];

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setIsAnalyzing(true);
    try {
      // AI Magic
      const result = await analyzeNutrition(input);
      
      if (result) {
        onAddFood({
          id: Date.now().toString(),
          name: result.name,
          calories: result.calories,
          protein: result.protein,
          carbs: result.carbs,
          fat: result.fat,
          meal: selectedMeal
        });
        setInput('');
      } else {
        alert("Não consegui identificar este alimento. Tente descrever melhor.");
      }
    } catch (err) {
      console.error(err);
      alert("Erro ao conectar com a IA.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSaveReminders = () => {
    onUpdateReminders(tempReminders);
    setIsReminderModalOpen(false);
  };

  const toggleReminder = (type: MealType) => {
    setTempReminders(prev => prev.map(r => 
        r.type === type ? { ...r, isEnabled: !r.isEnabled } : r
    ));
  };

  const updateReminderTime = (type: MealType, time: string) => {
    setTempReminders(prev => prev.map(r => 
        r.type === type ? { ...r, time } : r
    ));
  };

  // Calculate Macros
  const totalProteins = foodLog.reduce((acc, item) => acc + item.protein, 0);
  const totalCarbs = foodLog.reduce((acc, item) => acc + item.carbs, 0);
  const totalFats = foodLog.reduce((acc, item) => acc + item.fat, 0);
  
  const percentage = Math.min(100, (stats.caloriesCurrent / stats.caloriesGoal) * 100);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in relative">
      
      {/* Header Summary */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 relative">
        {/* Settings Button */}
        <button 
            onClick={() => {
                setTempReminders(mealReminders);
                setIsReminderModalOpen(true);
            }}
            className="absolute top-6 right-6 p-2 text-slate-400 hover:text-orange-500 hover:bg-orange-50 rounded-lg transition-colors"
            title="Configurar Lembretes de Refeição"
        >
            <IconClock className="w-5 h-5" />
        </button>

        <div className="flex flex-col md:flex-row justify-between items-center gap-6 pr-10">
            <div className="flex items-center gap-4">
                <div className="p-4 bg-orange-100 rounded-full text-orange-500">
                    <IconApple className="w-8 h-8" />
                </div>
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">Diário Alimentar</h2>
                    <p className="text-slate-500 text-sm">Acompanhe suas calorias e nutrientes.</p>
                </div>
            </div>

            <div className="flex-1 w-full md:w-auto">
                 <div className="flex justify-between items-end mb-2">
                    <div>
                        <span className="text-3xl font-bold text-slate-800">{stats.caloriesCurrent}</span>
                        <span className="text-slate-400 text-sm ml-1">kcal consumidas</span>
                    </div>
                    <div className="text-right">
                        {isEditingGoal ? (
                             <input 
                                type="number"
                                value={tempGoal}
                                onChange={(e) => setTempGoal(e.target.value)}
                                onBlur={() => {
                                    const val = parseInt(tempGoal);
                                    if(val > 0) onUpdateGoal(val);
                                    setIsEditingGoal(false);
                                }}
                                autoFocus
                                className="w-20 text-right border-b border-orange-500 outline-none font-semibold text-slate-600"
                             />
                        ) : (
                            <span 
                                onClick={() => setIsEditingGoal(true)}
                                className="font-semibold text-slate-600 cursor-pointer border-b border-dashed border-slate-300 hover:text-orange-500 hover:border-orange-500"
                            >
                                Meta: {stats.caloriesGoal}
                            </span>
                        )}
                    </div>
                 </div>
                 <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                        className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full transition-all duration-700"
                        style={{ width: `${percentage}%` }}
                    />
                 </div>
            </div>
        </div>

        {/* Macros */}
        <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-slate-50">
            <div className="text-center">
                <p className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-1">Proteínas</p>
                <p className="text-lg font-bold text-slate-700">{Math.round(totalProteins)}g</p>
                <div className="h-1.5 w-full bg-slate-100 rounded-full mt-2">
                    <div className="h-full bg-blue-400 rounded-full" style={{ width: `${Math.min(100, totalProteins)}%` }}></div>
                </div>
            </div>
            <div className="text-center border-l border-r border-slate-100 px-4">
                <p className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-1">Carboidratos</p>
                <p className="text-lg font-bold text-slate-700">{Math.round(totalCarbs)}g</p>
                <div className="h-1.5 w-full bg-slate-100 rounded-full mt-2">
                    <div className="h-full bg-green-400 rounded-full" style={{ width: `${Math.min(100, totalCarbs / 2)}%` }}></div>
                </div>
            </div>
            <div className="text-center">
                <p className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-1">Gorduras</p>
                <p className="text-lg font-bold text-slate-700">{Math.round(totalFats)}g</p>
                <div className="h-1.5 w-full bg-slate-100 rounded-full mt-2">
                    <div className="h-full bg-yellow-400 rounded-full" style={{ width: `${Math.min(100, totalFats)}%` }}></div>
                </div>
            </div>
        </div>
      </div>

      {/* Input Area */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 p-6 rounded-2xl shadow-lg text-white">
        <label className="block text-sm font-medium text-slate-300 mb-2">Adicionar alimento (IA)</label>
        <form onSubmit={handleAdd} className="relative">
            <input 
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ex: 2 ovos cozidos e uma fatia de pão integral"
                className="w-full pl-4 pr-32 py-4 bg-slate-700/50 border border-slate-600 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none text-white placeholder:text-slate-400 transition-all"
                disabled={isAnalyzing}
            />
            <div className="absolute right-2 top-2 bottom-2">
                 <button 
                    type="submit"
                    disabled={isAnalyzing || !input.trim()}
                    className="h-full px-4 bg-orange-500 hover:bg-orange-600 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-colors flex items-center gap-2"
                >
                    {isAnalyzing ? (
                         <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                        <>
                            <IconSparkles className="w-4 h-4" />
                            <span>Adicionar</span>
                        </>
                    )}
                </button>
            </div>
        </form>
        <div className="flex gap-4 mt-4 overflow-x-auto pb-2 scrollbar-hide">
            {mealsList.map((m) => (
                <button
                    key={m.key}
                    onClick={() => setSelectedMeal(m.key)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors border ${
                        selectedMeal === m.key 
                        ? 'bg-white text-slate-900 border-white' 
                        : 'bg-transparent text-slate-400 border-slate-600 hover:border-slate-500'
                    }`}
                >
                    {m.label}
                </button>
            ))}
        </div>
      </div>

      {/* Food Log List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mealsList.map((meal) => {
            const items = foodLog.filter(f => f.meal === meal.key);
            const mealCalories = items.reduce((acc, i) => acc + i.calories, 0);

            // Find reminder time for this meal
            const reminder = mealReminders.find(r => r.type === meal.key);

            return (
                <div key={meal.key} className="bg-white p-5 rounded-xl border border-slate-200">
                    <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-100">
                        <div>
                            <div className="flex items-center gap-2">
                                <h3 className="font-bold text-slate-700">{meal.label}</h3>
                                {reminder?.isEnabled && (
                                    <span className="text-[10px] bg-orange-100 text-orange-600 px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                                        <IconClock className="w-3 h-3" />
                                        {reminder.time}
                                    </span>
                                )}
                            </div>
                        </div>
                        <span className="text-sm font-bold text-orange-500">{mealCalories} kcal</span>
                    </div>

                    <div className="space-y-3">
                        {items.length === 0 ? (
                            <p className="text-sm text-slate-400 italic text-center py-4">Nada registrado.</p>
                        ) : (
                            items.map(item => (
                                <div key={item.id} className="flex justify-between items-start group">
                                    <div>
                                        <p className="text-sm font-medium text-slate-800">{item.name}</p>
                                        <p className="text-xs text-slate-500">
                                            P: {item.protein}g • C: {item.carbs}g • G: {item.fat}g
                                        </p>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        <span className="text-xs font-semibold text-slate-600">{item.calories}</span>
                                        <button 
                                            onClick={() => onRemoveFood(item.id)}
                                            className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                        >
                                            ×
                                        </button>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )
        })}
      </div>

      {/* Reminders Modal */}
      {isReminderModalOpen && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl animate-fade-in-up">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                          <IconClock className="w-6 h-6 text-orange-500" />
                          Lembretes de Refeição
                      </h3>
                      <button onClick={() => setIsReminderModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                          ✕
                      </button>
                  </div>
                  
                  <div className="space-y-4">
                      {tempReminders.map((reminder) => (
                          <div key={reminder.type} className="flex items-center justify-between p-3 border border-slate-100 rounded-lg hover:border-orange-200 transition-colors">
                              <div className="flex-1">
                                  <p className="font-medium text-slate-700">{reminder.label}</p>
                              </div>
                              
                              <div className="flex items-center gap-3">
                                  <input 
                                      type="time" 
                                      value={reminder.time}
                                      disabled={!reminder.isEnabled}
                                      onChange={(e) => updateReminderTime(reminder.type, e.target.value)}
                                      className={`p-1 border rounded text-sm outline-none focus:border-orange-500 ${!reminder.isEnabled ? 'text-slate-300 bg-slate-50' : 'text-slate-700'}`}
                                  />
                                  <button
                                      onClick={() => toggleReminder(reminder.type)}
                                      className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors duration-300 focus:outline-none ${
                                          reminder.isEnabled ? 'bg-orange-500 justify-end' : 'bg-slate-300 justify-start'
                                      }`}
                                  >
                                      <div className="w-4 h-4 bg-white rounded-full shadow-md" />
                                  </button>
                              </div>
                          </div>
                      ))}
                  </div>

                  <div className="flex gap-3 mt-8 pt-4 border-t border-slate-100">
                      <button 
                          onClick={() => setIsReminderModalOpen(false)}
                          className="flex-1 py-2.5 text-slate-600 font-medium hover:bg-slate-50 rounded-lg transition-colors"
                      >
                          Cancelar
                      </button>
                      <button 
                          onClick={handleSaveReminders}
                          className="flex-1 py-2.5 bg-orange-500 text-white font-medium rounded-lg hover:bg-orange-600 transition-colors shadow-sm"
                      >
                          Salvar Configurações
                      </button>
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};

export default NutritionTracker;