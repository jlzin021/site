
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from './services/supabaseClient';
import * as db from './services/dataService';
import { View, Medication, DailyStats, FoodItem, MealReminder, UserProfile, Achievement, GamificationProfile } from './types';
import Dashboard from './components/Dashboard';
import MedicationTracker from './components/MedicationTracker';
import HydrationTracker from './components/HydrationTracker';
import NutritionTracker from './components/NutritionTracker';
import AiAssistant from './components/AiAssistant';
import GamificationHub from './components/GamificationHub';
import AuthScreen from './components/AuthScreen';
import { IconHome, IconDroplet, IconPill, IconApple, IconSparkles, IconMenu, IconTrophy, IconLogOut } from './components/Icons';

// --- Sound Effects ---
const playNotificationSound = () => {
  try {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
    audio.volume = 0.5;
    audio.play().catch(e => console.log('Audio blocked', e));
  } catch (e) {}
};

const playSuccessSound = () => {
  try {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3');
    audio.volume = 0.4;
    audio.play().catch(e => console.log('Audio blocked', e));
  } catch (e) {}
};

const playLevelUpSound = () => {
    try {
        const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3');
        audio.volume = 0.5;
        audio.play().catch(e => console.log('Audio blocked', e));
    } catch (e) {}
}

const DEFAULT_GAMIFICATION: GamificationProfile = {
    xp: 0,
    level: 1,
    unlockedAchievements: [
        { id: 'first_login', title: 'Primeiro Passo', description: 'Iniciou sua jornada no SlimFit.', iconType: 'flag', unlockedAt: Date.now() }
    ],
    streakDays: 1
};

const LEVEL_THRESHOLDS = [0, 100, 300, 600, 1000, 1500, 2500, 5000];

const App: React.FC = () => {
  // --- Auth State ---
  const [session, setSession] = useState<any>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // --- App View State ---
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // --- Data State ---
  const [medications, setMedications] = useState<Medication[]>([]);
  const [foodLog, setFoodLog] = useState<FoodItem[]>([]);
  const [dailyStats, setDailyStats] = useState<DailyStats>({
      waterGoal: 2500,
      waterCurrent: 0,
      medicationTotal: 0,
      medicationTaken: 0,
      steps: 0,
      caloriesGoal: 2000,
      caloriesCurrent: 0
  });

  // Local-only state for reminders (for now, or could store in JSON in profile)
  const [mealReminders, setMealReminders] = useState<MealReminder[]>([
    { type: 'breakfast', label: 'Café da Manhã', time: '08:00', isEnabled: false },
    { type: 'lunch', label: 'Almoço', time: '12:00', isEnabled: true },
    { type: 'snack', label: 'Lanche da Tarde', time: '16:00', isEnabled: false },
    { type: 'dinner', label: 'Jantar', time: '19:30', isEnabled: true },
  ]);

  const [activeAlert, setActiveAlert] = useState<{name: string, time: string, type: 'medication' | 'meal'} | null>(null);
  const [rewardAlert, setRewardAlert] = useState<{ title: string, message: string, icon: React.ReactNode } | null>(null);

  // --- 1. Auth Initialization ---
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) fetchUserData(session.user.id);
      else setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) fetchUserData(session.user.id);
      else {
        setUser(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchUserData = async (userId: string) => {
    setLoading(true);
    try {
        // 1. Get Profile & Stats
        const { profile, stats } = await db.getProfile(userId);
        
        if (profile) {
            setUser(profile);
            // Cache name for AuthScreen
            localStorage.setItem('slimfit_user_name', profile.name);
            if (stats) setDailyStats(prev => ({ ...prev, ...stats }));
        } else {
            // New user without profile table entry (fallback) or race condition on signup
            const cachedName = localStorage.getItem('slimfit_user_name');
            setUser({ 
                id: userId, 
                name: cachedName || 'Usuário', 
                username: 'user', 
                gamification: DEFAULT_GAMIFICATION 
            });
        }

        // 2. Get Meds
        const meds = await db.getMedications(userId);
        setMedications(meds);
        setDailyStats(prev => ({
            ...prev,
            medicationTotal: meds.length,
            medicationTaken: meds.filter(m => m.taken).length
        }));

        // 3. Get Food
        const foods = await db.getFoodLogs(userId);
        setFoodLog(foods);
        const totalCals = foods.reduce((acc, i) => acc + i.calories, 0);
        setDailyStats(prev => ({ ...prev, caloriesCurrent: totalCals }));

    } catch (error) {
        console.error("Error loading data:", error);
    } finally {
        setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setMedications([]);
    setFoodLog([]);
    // Don't clear cached name so login screen remembers it
  };

  // --- Sync Data Helpers ---
  
  // Gamification Sync
  const syncGamification = async (updatedUser: UserProfile) => {
      if (!session) return;
      await db.updateGamification(session.user.id, updatedUser.gamification);
  };

  // Stats Sync (Debounced ideally, but here direct)
  const syncStats = async (updatedStats: DailyStats) => {
      if (!session) return;
      await db.updateDailyStats(session.user.id, updatedStats);
  };

  // --- Logic ---

  const showReward = (title: string, message: string, icon: React.ReactNode) => {
    setRewardAlert({ title, message, icon });
    playSuccessSound(); 
    setTimeout(() => setRewardAlert(null), 5000);
  };

  const updateGamification = (amount: number, newAchievementId?: string) => {
    if (!user) return;

    setUser(prevUser => {
        if (!prevUser) return null;

        let newXp = prevUser.gamification.xp + amount;
        let newLevel = prevUser.gamification.level;
        let newAchievements = [...prevUser.gamification.unlockedAchievements];
        let leveledUp = false;

        const nextLevelThreshold = LEVEL_THRESHOLDS[newLevel];
        if (nextLevelThreshold && newXp >= nextLevelThreshold) {
            newLevel++;
            leveledUp = true;
        }

        if (newAchievementId && !newAchievements.some(a => a.id === newAchievementId)) {
            const map: Record<string, any> = {
                'water_master': { id: 'water_master', title: 'Mestre da Hidratação', description: 'Atingiu a meta de água.', iconType: 'medal' },
                'med_perfect': { id: 'med_perfect', title: 'Farmácia em Dia', description: 'Tomou todos os remédios.', iconType: 'star' },
                'nutrition_start': { id: 'nutrition_start', title: 'Nutrição Consciente', description: 'Registrou comida.', iconType: 'medal' }
            };
            const details = map[newAchievementId];
            if (details) {
                newAchievements.push({ ...details, unlockedAt: Date.now() });
                showReward("Conquista Desbloqueada!", details.title, <IconTrophy className="w-6 h-6" />);
            }
        }

        if (leveledUp) {
            playLevelUpSound();
            showReward("Level Up!", `Você alcançou o nível ${newLevel}!`, <IconTrophy className="w-6 h-6" />);
        }

        const updatedUser = {
            ...prevUser,
            gamification: {
                ...prevUser.gamification,
                xp: newXp,
                level: newLevel,
                unlockedAchievements: newAchievements
            }
        };

        syncGamification(updatedUser); // Sync to DB
        return updatedUser;
    });
  };

  // Actions

  const toggleMedication = async (id: string) => {
    const med = medications.find(m => m.id === id);
    if (!med || !session) return;

    const newStatus = !med.taken;
    
    // Optimistic Update
    setMedications(prev => prev.map(m => m.id === id ? { ...m, taken: newStatus } : m));
    
    // DB Update
    try {
        await db.updateMedicationStatus(id, newStatus);
        
        if (newStatus) {
            playSuccessSound();
            updateGamification(15);
        }

        // Check completion
        const allMeds = medications.map(m => m.id === id ? { ...m, taken: newStatus } : m);
        const allTaken = allMeds.every(m => m.taken);
        const prevAllTaken = medications.every(m => m.taken);
        
        setDailyStats(prev => {
             const newStats = {
                ...prev,
                medicationTaken: allMeds.filter(m => m.taken).length
             };
             syncStats(newStats);
             return newStats;
        });

        if (allTaken && !prevAllTaken && allMeds.length > 0) {
            updateGamification(100, 'med_perfect');
        }

    } catch (e) {
        console.error(e);
        // Revert on error would go here
    }
  };

  const addMedication = async (newMed: Medication) => {
    if (!session) return;
    try {
        const savedMed = await db.addMedication({ ...newMed, user_id: session.user.id } as any);
        setMedications(prev => [...prev, savedMed]);
        setDailyStats(prev => {
            const newStats = { ...prev, medicationTotal: prev.medicationTotal + 1 };
            syncStats(newStats);
            return newStats;
        });
    } catch (e) { console.error(e); }
  };

  const deleteMedication = async (id: string) => {
     try {
         await db.deleteMedication(id);
         setMedications(prev => prev.filter(m => m.id !== id));
         setDailyStats(prev => ({ ...prev, medicationTotal: prev.medicationTotal - 1 }));
     } catch (e) { console.error(e); }
  };

  const addWater = (amount: number) => {
    setDailyStats(prev => {
      const newCurrent = Math.max(0, prev.waterCurrent + amount);
      if (prev.waterCurrent < prev.waterGoal && newCurrent >= prev.waterGoal) {
          updateGamification(100, 'water_master');
      } else if (amount > 0) {
          updateGamification(5);
      }
      
      const newStats = { ...prev, waterCurrent: newCurrent };
      syncStats(newStats);
      return newStats;
    });
  };

  const updateWaterGoal = (newGoal: number) => {
      setDailyStats(prev => {
          const s = { ...prev, waterGoal: newGoal };
          syncStats(s);
          return s;
      });
  };

  const addFoodItem = async (item: FoodItem) => {
     if (!session) return;
     try {
         const savedFood = await db.addFoodLog({ ...item, user_id: session.user.id } as any);
         setFoodLog(prev => {
            const newLog = [...prev, savedFood];
            if (prev.length === 0) updateGamification(50, 'nutrition_start');
            else updateGamification(20);
            return newLog;
         });
         
         setDailyStats(prev => {
             const s = { ...prev, caloriesCurrent: prev.caloriesCurrent + item.calories };
             syncStats(s);
             return s;
         });

     } catch (e) { console.error(e); }
  };

  const removeFoodItem = async (id: string) => {
      const item = foodLog.find(f => f.id === id);
      try {
          await db.deleteFoodLog(id);
          setFoodLog(prev => prev.filter(i => i.id !== id));
          if (item) {
              setDailyStats(prev => ({ ...prev, caloriesCurrent: prev.caloriesCurrent - item.calories }));
          }
      } catch (e) { console.error(e); }
  };

  // --- Reminder Interval ---
  useEffect(() => {
    const intervalId = setInterval(() => {
      const now = new Date();
      const currentTime = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      
      const medToTake = medications.find(m => m.time === currentTime && !m.taken);
      if (medToTake && activeAlert?.name !== medToTake.name) {
          setActiveAlert({ name: medToTake.name, time: medToTake.time, type: 'medication' });
          playNotificationSound();
      }

      const mealToEat = mealReminders.find(m => m.isEnabled && m.time === currentTime);
      if (mealToEat && activeAlert?.name !== mealToEat.label) {
            setActiveAlert({ name: mealToEat.label, time: mealToEat.time, type: 'meal' });
            playNotificationSound();
      }
    }, 30000);
    return () => clearInterval(intervalId);
  }, [medications, mealReminders, activeAlert]);

  // --- Rendering ---

  if (loading) {
      return (
          <div className="h-screen flex items-center justify-center bg-slate-50">
              <div className="flex flex-col items-center gap-4">
                  <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
                  <p className="text-slate-500 font-medium animate-pulse">Carregando seus dados...</p>
              </div>
          </div>
      );
  }

  if (!session || !user) {
      return <AuthScreen onLoginSuccess={() => {}} />;
  }

  const NavItem = ({ view, icon: Icon, label }: { view: View; icon: React.FC<{className?:string}>; label: string }) => (
    <button
      onClick={() => {
        setCurrentView(view);
        setIsSidebarOpen(false);
      }}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
        currentView === view 
          ? 'bg-blue-600 text-white shadow-md shadow-blue-200' 
          : 'text-slate-500 hover:bg-slate-100 hover:text-slate-800'
      }`}
    >
      <Icon className="w-5 h-5" />
      <span className="font-medium">{label}</span>
    </button>
  );

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans relative">
      
      {/* Toast Reward */}
      {rewardAlert && (
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-[60] animate-bounce-in text-center pointer-events-none">
             <div className="bg-white p-8 rounded-3xl shadow-2xl border-4 border-yellow-400 flex flex-col items-center">
                <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-500 mb-4 animate-pulse">
                    {rewardAlert.icon}
                </div>
                <h2 className="text-2xl font-black text-slate-800 mb-2">{rewardAlert.title}</h2>
                <p className="text-slate-600 font-medium">{rewardAlert.message}</p>
             </div>
          </div>
      )}

      {/* Alert Notification */}
      {activeAlert && (
        <div className="fixed top-4 right-4 z-50 animate-bounce-in">
          <div className={`bg-white rounded-2xl shadow-2xl border-l-4 ${activeAlert.type === 'medication' ? 'border-blue-600' : 'border-orange-500'} p-4 flex items-start gap-4 max-w-sm`}>
            <div className={`p-2 rounded-full ${activeAlert.type === 'medication' ? 'bg-blue-100 text-blue-600' : 'bg-orange-100 text-orange-600'}`}>
              {activeAlert.type === 'medication' ? <IconPill className="w-6 h-6" /> : <IconApple className="w-6 h-6" />}
            </div>
            <div>
              <h4 className="font-bold text-slate-800">
                  {activeAlert.type === 'medication' ? 'Hora do Medicamento!' : 'Hora da Refeição!'}
              </h4>
              <p className="text-sm text-slate-600 mt-1">
                {activeAlert.type === 'medication' ? 'Tomar: ' : 'Comer: '}
                <strong>{activeAlert.name}</strong> ({activeAlert.time}).
              </p>
              <div className="flex gap-3">
                <button 
                    onClick={() => setActiveAlert(null)}
                    className="mt-3 text-xs font-semibold hover:opacity-80 text-blue-600"
                >
                    DISPENSAR
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 h-full p-6">
        <div className="flex items-center gap-3 mb-10 px-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <IconSparkles className="text-white w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold text-slate-800 tracking-tight">SlimFit</h1>
        </div>

        <nav className="flex-1 space-y-2">
          <NavItem view={View.DASHBOARD} icon={IconHome} label="Visão Geral" />
          <NavItem view={View.MEDICATIONS} icon={IconPill} label="Remédios" />
          <NavItem view={View.HYDRATION} icon={IconDroplet} label="Hidratação" />
          <NavItem view={View.NUTRITION} icon={IconApple} label="Nutrição" />
          <div className="pt-2"></div>
          <NavItem view={View.REWARDS} icon={IconTrophy} label="Conquistas" />
        </nav>

        <div className="pt-6 border-t border-slate-100 mt-6 space-y-2">
             <NavItem view={View.AI_ASSISTANT} icon={IconSparkles} label="Assistente IA" />
             <button 
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-slate-500 hover:bg-red-50 hover:text-red-600"
             >
                <IconLogOut className="w-5 h-5" />
                <span className="font-medium">Sair</span>
             </button>
        </div>
      </aside>

      {/* Main Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
         {/* Mobile Header */}
         <header className="md:hidden bg-white border-b border-slate-200 p-4 flex items-center justify-between sticky top-0 z-30">
           <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                    <IconSparkles className="text-white w-5 h-5" />
                </div>
                <h1 className="font-bold text-slate-800">SlimFit</h1>
           </div>
           <button onClick={() => setIsSidebarOpen(true)} className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg">
                <IconMenu className="w-6 h-6" />
           </button>
        </header>

        {/* Mobile Sidebar */}
        {isSidebarOpen && (
            <div className="fixed inset-0 bg-black/20 z-40 md:hidden" onClick={() => setIsSidebarOpen(false)}>
            <div className="absolute left-0 top-0 bottom-0 w-64 bg-white p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-3 mb-10 px-2">
                        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                            <IconSparkles className="text-white w-5 h-5" />
                        </div>
                        <h1 className="text-xl font-bold text-slate-800 tracking-tight">SlimFit</h1>
                    </div>
                    <nav className="flex-1 space-y-2">
                        <NavItem view={View.DASHBOARD} icon={IconHome} label="Visão Geral" />
                        <NavItem view={View.MEDICATIONS} icon={IconPill} label="Remédios" />
                        <NavItem view={View.HYDRATION} icon={IconDroplet} label="Hidratação" />
                        <NavItem view={View.NUTRITION} icon={IconApple} label="Nutrição" />
                        <NavItem view={View.REWARDS} icon={IconTrophy} label="Conquistas" />
                        <NavItem view={View.AI_ASSISTANT} icon={IconSparkles} label="Assistente IA" />
                        <button 
                            onClick={handleLogout}
                            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-red-500 mt-4"
                        >
                            <IconLogOut className="w-5 h-5" />
                            <span className="font-medium">Sair da Conta</span>
                        </button>
                    </nav>
            </div>
            </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
            <div className="max-w-5xl mx-auto">
                <div className="mb-6 md:mb-8 flex justify-between items-center animate-fade-in-up">
                    <div>
                        <h2 className="text-2xl font-bold text-slate-800">
                            {currentView === View.DASHBOARD && `Olá, ${user.name.split(' ')[0]} 👋`}
                            {currentView === View.MEDICATIONS && "Medicamentos"}
                            {currentView === View.HYDRATION && "Hidratação"}
                            {currentView === View.NUTRITION && "Nutrição"}
                            {currentView === View.AI_ASSISTANT && "SlimFit AI"}
                            {currentView === View.REWARDS && "Recompensas"}
                        </h2>
                        {currentView === View.DASHBOARD && (
                            <p className="text-slate-500 text-sm">Aqui está o resumo do seu dia.</p>
                        )}
                        {currentView === View.REWARDS && (
                            <p className="text-slate-500 text-sm">Visualize suas medalhas e progresso.</p>
                        )}
                    </div>
                    <div className="hidden md:flex items-center gap-3 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-sm">
                        <div className="text-xs font-bold text-yellow-600 bg-yellow-100 px-2 py-1 rounded-full flex items-center gap-1">
                            <IconTrophy className="w-3 h-3" />
                            Lvl {user.gamification.level}
                        </div>
                        <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-xs border border-blue-200 uppercase">
                            {user.name.charAt(0)}
                        </div>
                    </div>
                </div>
                
                {currentView === View.DASHBOARD && <Dashboard stats={dailyStats} userName={user.name} />}
                {currentView === View.MEDICATIONS && (
                    <MedicationTracker 
                        medications={medications} 
                        onToggle={toggleMedication} 
                        onAdd={addMedication}
                        onDelete={deleteMedication}
                    />
                )}
                {currentView === View.HYDRATION && (
                     <HydrationTracker 
                        stats={dailyStats} 
                        onAddWater={addWater} 
                        onUpdateGoal={(g) => updateWaterGoal(g)}
                     />
                )}
                {currentView === View.NUTRITION && (
                    <NutritionTracker 
                        stats={dailyStats}
                        foodLog={foodLog}
                        mealReminders={mealReminders} // Still local for now
                        onAddFood={addFoodItem}
                        onRemoveFood={removeFoodItem}
                        onUpdateGoal={(g) => setDailyStats(p => ({...p, caloriesGoal: g}))}
                        onUpdateReminders={setMealReminders}
                    />
                )}
                {currentView === View.AI_ASSISTANT && <AiAssistant />}
                {currentView === View.REWARDS && <GamificationHub profile={user.gamification} />}
            </div>
        </div>
      </main>
    </div>
  );
};

export default App;
