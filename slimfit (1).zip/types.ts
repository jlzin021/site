

export enum View {
  DASHBOARD = 'DASHBOARD',
  MEDICATIONS = 'MEDICATIONS',
  HYDRATION = 'HYDRATION',
  NUTRITION = 'NUTRITION',
  AI_ASSISTANT = 'AI_ASSISTANT',
  REWARDS = 'REWARDS'
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  iconType: 'medal' | 'trophy' | 'star' | 'flag' | 'crown';
  unlockedAt?: number; // timestamp
}

export interface GamificationProfile {
  xp: number;
  level: number;
  unlockedAchievements: Achievement[];
  streakDays: number;
}

export interface UserProfile {
  id: string; // Supabase Auth ID
  name: string;
  username: string;
  email?: string;
  avatar?: string;
  gamification: GamificationProfile;
}

export interface Medication {
  id: string;
  user_id?: string;
  name: string;
  dosage: string;
  time: string;
  taken: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface WaterLog {
  amount: number; // in ml
  timestamp: number;
}

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface FoodItem {
  id: string;
  user_id?: string;
  name: string;
  calories: number;
  protein: number; // grams
  carbs: number; // grams
  fat: number; // grams
  meal: MealType;
}

export interface MealReminder {
  type: MealType;
  label: string;
  time: string;
  isEnabled: boolean;
}

export interface DailyStats {
  waterGoal: number; // ml
  waterCurrent: number; // ml
  medicationTotal: number;
  medicationTaken: number;
  steps: number;
  caloriesGoal: number;
  caloriesCurrent: number;
}
