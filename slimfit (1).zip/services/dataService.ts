
import { supabase } from './supabaseClient';
import { UserProfile, Medication, FoodItem, DailyStats, GamificationProfile } from '../types';

// --- Profile & Stats ---

export const getProfile = async (userId: string): Promise<{ profile: UserProfile | null, stats: any }> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) {
    console.error('Error fetching profile:', error);
    return { profile: null, stats: null };
  }

  return {
    profile: {
      id: data.id,
      name: data.name,
      username: data.username,
      gamification: data.gamification || { xp: 0, level: 1, unlockedAchievements: [], streakDays: 1 }
    },
    stats: data.daily_stats
  };
};

export const createProfile = async (userId: string, name: string, username: string) => {
  const { error } = await supabase
    .from('profiles')
    .insert([
      { id: userId, name, username }
    ]);
  
  if (error) throw error;
};

export const updateGamification = async (userId: string, gamification: GamificationProfile) => {
  const { error } = await supabase
    .from('profiles')
    .update({ gamification })
    .eq('id', userId);
    
  if (error) console.error("Error saving gamification:", error);
};

export const updateDailyStats = async (userId: string, stats: Partial<DailyStats>) => {
    // We store stats in a jsonb column 'daily_stats' in profiles for simplicity in this implementation
    // Ideally this would be a separate table 'daily_logs'
    const { error } = await supabase
      .from('profiles')
      .update({ daily_stats: stats })
      .eq('id', userId);

    if (error) console.error("Error saving stats:", error);
};

// --- Medications ---

export const getMedications = async (userId: string): Promise<Medication[]> => {
  const { data, error } = await supabase
    .from('medications')
    .select('*')
    .eq('user_id', userId);

  if (error) {
    console.error(error);
    return [];
  }
  return data || [];
};

export const addMedication = async (med: Omit<Medication, 'id'>) => {
  const { data, error } = await supabase
    .from('medications')
    .insert([med])
    .select()
    .single();
    
  if (error) throw error;
  return data;
};

export const updateMedicationStatus = async (medId: string, taken: boolean) => {
  const { error } = await supabase
    .from('medications')
    .update({ taken })
    .eq('id', medId);
    
  if (error) throw error;
};

export const deleteMedication = async (medId: string) => {
  const { error } = await supabase
    .from('medications')
    .delete()
    .eq('id', medId);
    
  if (error) throw error;
};

// --- Nutrition ---

export const getFoodLogs = async (userId: string): Promise<FoodItem[]> => {
  const { data, error } = await supabase
    .from('food_logs')
    .select('*')
    .eq('user_id', userId);

  if (error) return [];
  return data || [];
};

export const addFoodLog = async (food: Omit<FoodItem, 'id'>) => {
  const { data, error } = await supabase
    .from('food_logs')
    .insert([food])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const deleteFoodLog = async (foodId: string) => {
  const { error } = await supabase
    .from('food_logs')
    .delete()
    .eq('id', foodId);

  if (error) throw error;
};
