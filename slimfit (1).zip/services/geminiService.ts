

import { GoogleGenAI } from "@google/genai";

// Initialize Gemini API client
// Ideally, in a real production app, we would handle this via a backend proxy to secure the key.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateHealthAdvice = async (
  userQuery: string,
  context: string
): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Contexto do usuário: ${context}\n\nPergunta do usuário: ${userQuery}`,
      config: {
        systemInstruction: "Você é o SlimFit AI, um assistente de saúde empático, profissional e motivador. Forneça conselhos breves, práticos e baseados em ciência sobre bem-estar, hidratação, nutrição e hábitos saudáveis. Nunca forneça diagnósticos médicos definitivos; sempre sugira consultar um médico para problemas graves. Responda em Português do Brasil.",
      }
    });
    return response.text || "Desculpe, não consegui processar sua solicitação no momento.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Ocorreu um erro ao conectar com o assistente inteligente. Por favor, tente novamente.";
  }
};

export const analyzeDailySummary = async (
  stats: string
): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analise estes dados do dia do usuário e dê uma frase motivacional curta ou um alerta gentil: ${stats}`,
    });
    return response.text || "Continue cuidando da sua saúde!";
  } catch (error) {
    return "Mantenha o foco na sua saúde!";
  }
};

export const analyzeNutrition = async (foodDescription: string): Promise<{ name: string, calories: number, protein: number, carbs: number, fat: number } | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analise o seguinte alimento ou refeição: "${foodDescription}". Estime as calorias e macronutrientes (proteína, carboidratos, gordura) para uma porção padrão. Retorne APENAS um objeto JSON válido sem formatação markdown. Formato esperado: {"name": "Nome curto formatado", "calories": numero, "protein": numero, "carbs": numero, "fat": numero}. Se não for um alimento, retorne null no JSON.`,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) return null;
    return JSON.parse(text);
  } catch (error) {
    console.error("Nutrition Analysis Error:", error);
    return null;
  }
};